# skibidi ไอ เอลฟ์ นี่ ไง ที่ เองทำไว ที่ โรงเรียน ตันตรารักษ อะ
oh oh ohio this was just my file that i use in scracht whatever ELFFY
